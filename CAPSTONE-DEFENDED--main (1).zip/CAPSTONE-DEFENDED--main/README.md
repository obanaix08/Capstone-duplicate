INSTRUCTIONS!!


CAPSTONE-BACK

composer install 

php artisan key:generate

gagawa ng .env file

php artisan migrate

php artisan db:seed

php artisan serve


----------------------------------------------------------
CAPSTONE-FRONT

npm install

npm install axios react-router-dom

npm install react-bootstrap

npm install lucide-react

npm install framer-motion

npm install bootstrap

npm start
